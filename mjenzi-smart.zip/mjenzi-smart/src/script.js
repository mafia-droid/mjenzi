<script>
function openTab(tabName) {
    const tabs = document.querySelectorAll('.auth-content');
    tabs.forEach(tab => {
        tab.style.display = 'none';
    });

    const activeTab = document.getElementById(tabName);
    activeTab.style.display = 'block';
}

document.getElementById('employee-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employee Registered');
    // Add your registration logic here
});

document.getElementById('employee-login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employee Logged In');
    // Add your login logic here
});

document.getElementById('employer-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employer Registered');
    // Add your registration logic here
});

document.getElementById('employer-login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employer Logged In');
    // Add your login logic here
});
</script>


<script>
function openTab(tabName) {
    const tabs = document.querySelectorAll('.auth-content');
    tabs.forEach(tab => {
        tab.style.display = 'none';
    });

    const activeTab = document.getElementById(tabName);
    activeTab.style.display = 'block';
}

document.getElementById('employee-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employee Registered');
    // Add your registration logic here
});

document.getElementById('employee-login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employee Logged In');
    // Add your login logic here
});

document.getElementById('employer-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employer Registered');
    // Add your registration logic here
});

document.getElementById('employer-login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Employer Logged In');
    // Add your login logic here
});
</script>
